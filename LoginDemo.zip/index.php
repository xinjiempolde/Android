<?php
$iipp=$_SERVER["REMOTE_ADDR"];
if($iipp == "211.137.22.216")
{
	echo "您的IP不可用";
}
else
{
	echo '<script>window.location.href=\'http://39.96.26.6/PcOrPhone.html\'</script>';
}
?>