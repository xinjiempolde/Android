/*!
 * 深澜软件Javascript Library
 * Srun4K 双栈认证,工具函数 - v1.0.0 (2016-10-08)
 */

/**
 * 另一协议栈的认证地址 如果当前为IPV4，则此地址为IPV6
 * @type {string}
 */
var double_stack_auth_pc = "";
/**
 * 认证成功后返回的会话串用以双栈认证或自动登录自服务
 * @type {string}
 */
var info = "";
/**
 * 当前协议栈的用户源地址
 * @type {string}
 */
var stack_user_ip = "";

/**
 * 页面内认证
 * @param frm
 * @returns {boolean}
 */
function check(frm) {
    if (frm.username.value == "") {
        alert("请填写用户名");
        frm.username.focus();
        return false;
    }

    if (frm.password.value == "") {
        alert("请填写密码");
        frm.password.focus();
        return false;
    }

    return true;
}

/**
 * portal认证
 * @param form
 * @returns {boolean}
 */
function Auth(form, client_type) {
    if (form.username.value == "") {
        alert("请填写用户名");
        form.username.focus();
        return false;
    }

    if (form.password.value == "") {
        alert("请填写密码");
        form.password.focus();
        return false;
    }

    if (form.ac_id.value == "" || form.ac_id.value == "0") {
        alert("您打开的认证页面未经重定向，点击确定后将自动重定向到正确的页面。");
        location = "http://www.baidu.com";
        return false;
    }

    var save_me = 0;
    if ($("input[name='save_me']").is(':checked')) {
        save_me = 1;
    }

    var qData = {
        "action": "login",
        "username": form.username.value,
        "password": form.password.value,
        "ac_id": 1,
        "user_ip": form.user_ip.value,
        "ip": form.user_ip.value,
        "nas_ip": form.nas_ip.value,
        "user_mac": form.user_mac.value,
        "save_me": save_me,
        "type": 1,
        "n": 100,
        "ajax": 1
    };

    $.ajaxSettings.async = false;
    $.getJSON(getAuthAddr(), qData, function(data) {
        handleSuccess(data, client_type);
    });
}

/**
 * 获取认证地址
 * @returns {string}
 */
function getAuthAddr() {
    //协议
    var protocol = document.location.protocol;
    //主机地址
    var hostname = document.location.hostname;
    //接口请求地址
    return protocol + "//" + hostname + "/cgi-bin/srun_portal";
}

/**
 * 处理请求成功后的业务
 * @param result
 * @returns {boolean}
 */
function handleSuccess(result, client_type) {

    if (result.ecode) {
        var params = handleResult(result.ecode);
    } else if (result.error_msg) {
        var params = handleResult(result.error_msg);
    } else if (result.error) {
        var params = handleResult(result.error);
    } else {
        alert('未知错误...');
    }

    if (params == '登录成功')//认证成功，弹出小窗口
    {
        if (client_type == 'pc') {
            //弹出小窗口
            window.open("srun_portal_pc_succeed.php", "", "width=450,height=350,left=0,top=0,resizable=1");
        } else {
            //设置 cookie 属性来控制页面的div显示以及隐藏
            $.cookie('form3', 'show');
            $.cookie('notice', params);
            //window.location.href = 'srun_portal_phone.php?ac_id=1';
        }

        //重定向到输入的网址
        setTimeout("redirect()", 2000);
    } else if (params.indexOf("http") >= 0) {
        window.location = params;
    } else {
        //提示错误信息
        alert(params);
    }
    return false;
}

/**
 * 用户下线设置form3属性
 */
function setPortalAuthResult() {
    $.cookie('form3', 'hide');
}

/**
 * 弹窗认证--手机页面，在同一个页面内显示认证结果
 * @param frm
 * @returns {boolean}
 */
function check2(frm) {
    if (frm.username.value == "") {
        alert("请填写用户名");
        frm.username.focus();
        return false;
    }

    if (frm.password.value == "") {
        alert("请填写密码");
        frm.password.focus();
        return false;
    }

    if (frm.ac_id.value == "" || frm.ac_id.value == "0") {
        alert("您打开的认证页面未经重定向，点击确定后将自动重定向到正确的页面。");
        location = "http://www.baidu.com";
        return false;
    }

    var res1 = "";

    var save_me = 0;
    if (frm.save_me) {
        save_me = (frm.save_me.checked) ? 1 : 0;
    }

    var is_second = 0;

    if (frm.is_second) {
        is_second = frm.is_second.value;
    }

    $.post("/include/auth_action.php", {
        action: 'login',
        username: $("input[name='username']").val(),
        password: frm.password.value,
        ac_id: $("input[name='ac_id']").val(),
        user_mac: $("input[name='user_mac']").val(),
        user_ip: $("input[name='user_ip']").val(),
        nas_ip: $("input[name='nas_ip']").val(),
        save_me: document.form2.save_me.value,
        ajax: 1
    }, function (res1) {
        var p = /^login_ok,/;
        if (p.test(res1))//认证成功，弹出小窗口
        {
            var arr = res1.split(",");

            //写入用于双栈认证的COOKIE
            if (arr[1] != "") {
                //setCookie("double_stack_login", arr[1]);
            }
            //写入用户名密码COOKIE
            if (arr[2] != "") {
                setCookie("login", arr[2]);
            }

            $("#id_login")[0].style.display = 'none';
            $("#id_login_ok")[0].style.display = '';

            info = decodeURIComponent(arr[1]);

            if (double_stack_auth_pc != "" && double_stack_auth_pc != "0") {
                auto_login(double_stack_auth_pc, info, stack_user_ip);
            } else {
                setTimeout("get_online_info1()", 2000);
            }

        } else {
            if (res1 == "E2901: (Third party 1)userid error1()") {
                alert("Account does not exist.(用户名错误)");
            } else if (res1 == "E2901: (Third party -1)userid error2()") {
                alert("Password is error.(密码错误)");
            } else {
                alert(res1); //提示错误信息
            }

        }
    });

    return false;
}

/**
 * 弹窗认证
 * @param frm
 * @returns {boolean}
 */
function check3(frm) {
    if (frm.username.value == "") {
        alert("Please enter your username");
        frm.username.focus();
        return false;
    }

    if (frm.password.value == "") {
        alert("Please fill in the password");
        frm.password.focus();
        return false;
    }
    var res1 = "";
    var e = encodeURIComponent(base64encode(utf16to8(frm.password.value)));

    //var save_me = (frm.save_me.checked) ? 1 : 0;
    var d = "action=login&username=" + encodeURIComponent(frm.username.value) +
        "&password={B}" + e +
        "&ac_id=" + $("input[name='ac_id']").val() +
        "&user_ip=" + $("input[name='user_ip']").val() +
        "&nas_ip=" + $("input[name='nas_ip']").val() +
        "&user_mac=" + $("input[name='user_mac']").val() +
        //"&save_me="+save_me+
        "&ajax=1";

    //这里要用AJAX同步提交POST
    $.ajax({
        type: "post",
        url: "/include/auth_action.php",
        data: d,
        async: false,
        success: function (res) {
            res1 = res;
        }
    });

    var p = /^login_ok,/;
    if (p.test(res1))//认证成功，弹出小窗口
    {
        var arr = res1.split(",");
        //写入用于双栈认证的COOKIE
        if (arr[1] != "") {
            setCookie("double_stack_login", arr[1]);
        }
        //写入用户名密码COOKIE
        if (arr[2] != "") {
            setCookie("login", arr[2]);
        }

        //window.location.href="srun_portal_success1.php";    //跳转英文成功页面
        //window.open("srun_pc_success.php", "","width=450,height=350,left=0,top=0,resizable=1");//弹出英文成功页面小窗口

        setTimeout("redirect()", 2000); //重定向到输入的网址
    } else {
        alert(res1); //提示错误信息
    }

    return false;
}

/**
 * 认证
 * @param frm
 * @returns {boolean}
 */
function checks(frm) {
    var res1 = "";

    if (frm.username.value == "") {
        alert("请填写用户名");
        frm.username.focus();
        return false;
    }

    if (frm.password.value == "") {
        alert("请填写密码");
        frm.password.focus();
        return false;
    }

    var e = encodeURIComponent(base64encode(utf16to8(frm.password.value)));

    //var save_me = (frm.save_me.checked) ? 1 : 0;
    var d = "action=login&username=" + encodeURIComponent(frm.username.value) +
        "&password={B}" + e +
        "&ac_id=" + $("input[name='ac_id']").val() +
        "&user_ip=" + $("input[name='user_ip']").val() +
        "&nas_ip=" + $("input[name='nas_ip']").val() +
        "&user_mac=" + $("input[name='user_mac']").val() +
        //"&save_me="+save_me+
        "&ajax=1";

    //这里要用AJAX同步提交POST
    $.ajax({
        type: "post",
        url: "/include/demo.php",
        data: d,
        async: false,
        success: function (res) {
            res1 = res;
        }
    });
}

/**
 * 双栈认证，使用jsonp提交到另一协议栈
 * @param postUrl
 * @param info
 * @param user_ip
 * @returns {boolean}
 */
function auto_login(postUrl, info, user_ip) {

    $.getJSON("http://" + postUrl + "/include/auth_action.php?callback=?", {
        action: "auto_login",
        info: info,
        user_ip: user_ip,
        jsonp: 1
    }, function (data) {
        if (data.res == 'login_ok') {
            stack_user_ip = data.user_ip;
            $("#stack_msg").html("双栈登录成功");
        } else if (data.res != "") {
            alert(data.res);
        } else {
            alert("认证失败");
        }
    });
    return false;
}

/**
 * 双栈注销
 */
function auto_logout() {
    $.post("/include/auth_action.php", {
        action: "auto_logout",
        info: info,
        user_ip: stack_user_ip,
        ajax: 1
    }, function (res) {
        if (res == "网络已断开") {
            info = '';
            stack_user_ip = '';
            location = 'http://www.baidu.com';
        }
        else {
            alert(res);
        }
    });
}

/**
 * 远程注销
 * @param frm
 */
function do_logout(frm) {
    $.post("/include/auth_action.php", {
        action: "logout",
        username: $("input[name='username']").val(),
        password: $("input[name='password']").val(),
        ajax: 1
    }, function (res) {
        alert(res);
    });
}

/**
 * 重定向到输入的网址
 */
function redirect() {
    var url = $("input[name='url']").val();
    if (url != "") {
        location = url;
    }
}

/**
 * 处理返回值
 * @param params
 * @returns {*}
 */
function handleResult(params) {
    if (errorResultSet[params]) {
        return errorResultSet[params];
    } else {
        return '未知错误';
    }
}

/**
 * 错误代码翻译
 * @type {Array}
 */
var errorResultSet = new Array();
errorResultSet["account_password_error"] = "密码错误";
errorResultSet["user_tab_error"] = "认证程序未启动";
errorResultSet["username_error"] = "用户名输入错误";
errorResultSet["logout_error"] = "注销时发生错误;或没有帐号在线！";
errorResultSet["uid_error"] = "您的账号不在线上.";
errorResultSet["logout_ok"] = "注销成功，请等1分钟后登录。";
errorResultSet["login_ok"] = "登录成功";
errorResultSet["ok"] = "登录成功";
errorResultSet["mac_error"] = "您的MAC地址不正确";
errorResultSet["password_error"] = "用户名或密码错误;请重新输入！";
errorResultSet["non_auth_error"] = "您无须认证，可直接上网";
errorResultSet["status_error"] = "您已欠费，请尽快充值。";
errorResultSet["sync_error"] = "您的资料已被修改正在等待同步，请2钟分后再试。\n如果您的帐号允许多个用户上线，请到WEB登录页面注销。";
errorResultSet["delete_error"] = "您的帐号已经被删除";
errorResultSet["ip_exist_error"] = "IP已存在，请稍后再试。";
errorResultSet["usernum_error"] = "在线用户已满，请稍后再试。";
errorResultSet["online_num_error"] = "正在注销在线账号，请重新连接";
errorResultSet["proxy_error"] = "你的IP地址和认证地址不附，可能是经过小路由器登录的。";
errorResultSet["mode_error"] = "系统已禁止客户端登录，请使用WEB方式登录。";
errorResultSet["flux_error"] = "您的流量已用尽。";
errorResultSet["minutes_error"] = "您的时长已用尽。";
errorResultSet["ip_error"] = "您的IP地址不合法，可能是：\n一、与绑的IP地址附；二、IP不允许在当前区域登录；";
errorResultSet["time_policy_error"] = "当前时段不允许连接。";
errorResultSet["available_error"] = "抱歉，您的帐号已禁用";
errorResultSet["Addr table error~login_error"] = "计费系统尚未授权，目前还不能使用！";
errorResultSet["ipv6_error"] = "您的IPv6地址不正确，请重新配置IPv6地址!";
errorResultSet["auth_resault_timeout_err"] = "认证服务无响应";
errorResultSet["The server is not responding."] = "后台服务器无响应;请联系管理员检查后台服务运行状态";
errorResultSet["IP has been online; please logout."] = "您的IP已经在线;可以直接上网;或者先注销再重新认证";
//errorResultSet["You are not online."] = "注销成功";
errorResultSet["You have been forcibly disconnected"] = "您已经被服务器强制下线！";
errorResultSet["Authentication failed, but no error message is returned."] = "身份验证失败，但不返回错误消息。";

errorResultSet["E2611"] = "您当前使用的设备非该账号绑定设备 请绑定或使用绑定的设备登入";
errorResultSet["E2602"] = "您还没有绑定手机号或绑定的非联通手机号码";
errorResultSet["E2601"] = "您使用的不是专用客户端;IPOE-PPPoE混杂模式请联系管理员重新打包客户端程序";
errorResultSet["E2532"] = "您的两次认证的间隔太短;请稍候10秒后再重试登录";
errorResultSet["E2531"] = "帐号不存在或密码错误";
errorResultSet["E2553"] = "帐号或密码错误";
errorResultSet["E2533"] = "密码错误次数超过限制，请5分钟后再重试登录";
errorResultSet["E2807"] = "后台系统配置错误;请联系管理员检查后台计费策略配置";
errorResultSet["E2808"] = "后台系统配置错误;请联系管理员检查后台控制策略配置";
errorResultSet["E2606"] = "用户被禁用";
errorResultSet["E2613"] = "NAS PORT绑定错误";
errorResultSet["E2614"] = "MAC地址绑定错误";
errorResultSet["E2615"] = "IP地址绑定错误";
errorResultSet["E2616"] = "用户已欠费";
errorResultSet["E2620"] = "已经在线了";
errorResultSet["E2621"] = "已经达到授权人数";
errorResultSet["E2806"] = "找不到符合条件的产品";
errorResultSet["E2807"] = "找不到符合条件的计费策略";
errorResultSet["E2833"] = "IP不在DHCP表中，需要重新拿地址。";
errorResultSet["E2808"] = "找不到符合条件的控制策略";
errorResultSet["E2840"] = "校内地址不允许访问外网。";
errorResultSet["E2843"] = "IP地址不正确!";
errorResultSet["E2842"] = "您的IP地址无需认证即可上网";
