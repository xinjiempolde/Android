package com.example.appstudy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnpost = (Button)findViewById(R.id.btnpost);
        btnpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup rdgroup = (RadioGroup)findViewById(R.id.rdgroup);
                for (int i = 0; i < rdgroup.getChildCount(); i++){
                    RadioButton rdbutton = (RadioButton)rdgroup.getChildAt(i);
                    if (rdbutton.isChecked()){
                        Toast.makeText(getApplicationContext(), "点击提交按钮,获取你选择的是:" + rdbutton.getText(), Toast.LENGTH_LONG).show();
                        break;
                    }
                }
            }
        });
    }
}
