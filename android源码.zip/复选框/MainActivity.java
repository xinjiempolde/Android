package com.example.appstudy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private CheckBox one, two, theree;
    private Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        one = (CheckBox)findViewById(R.id.one);
        two = (CheckBox)findViewById(R.id.two);
        theree = (CheckBox)findViewById(R.id.three);
        btn = (Button)findViewById(R.id.btn);

        one.setOnCheckedChangeListener(this);
        two.setOnCheckedChangeListener(this);
        theree.setOnCheckedChangeListener(this);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        String choose = "";
        if (one.isChecked()){
            choose += one.getText().toString();
        }
        if (two.isChecked()){
            choose += two.getText().toString();
        }
        if (theree.isChecked()){
            choose += theree.getText().toString();
        }
        Toast.makeText(this,choose,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b){
        if (compoundButton.isChecked()){
            Toast.makeText(this,compoundButton.getText().toString(),Toast.LENGTH_SHORT).show();
        }
    }
}
