package com.example.appstudy;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Jay on 2015/9/28 0028.
 */
public class OtherActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
    }
}
