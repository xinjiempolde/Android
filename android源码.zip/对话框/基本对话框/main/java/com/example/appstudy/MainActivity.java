package com.example.appstudy;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private Context mContext;
    private Button btn_show_normal;
    private Button btn_close_normal;

    private AlertDialog alert = null;
    private AlertDialog.Builder mBuilder = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = MainActivity.this;
        btn_show_normal = (Button)findViewById(R.id.btn_show_normal);
        btn_show_normal.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        final String[] lession = new String[]{"语文","数学", "英语", "化学", "生物"};
        mBuilder = new AlertDialog.Builder(mContext);
        alert = mBuilder.setIcon(R.mipmap.head_icon1)
                .setTitle("系统提示：")
                .setSingleChoiceItems(lession, 1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(mContext,"你选择了" + lession[which],Toast.LENGTH_SHORT).show();
                    }
                })
                .create();
        alert.show();
    }
}