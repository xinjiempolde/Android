package com.example.appstudy;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button begin, stop;
    private Chronometer chronometer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    public void initView(){
        begin = (Button)findViewById(R.id.begin);
        stop = (Button)findViewById(R.id.stop);
        chronometer = (Chronometer)findViewById(R.id.ch);
        begin.setOnClickListener(this);
        stop.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.begin:
                chronometer.start();
                break;
            case R.id.stop:
                chronometer.stop();
                break;
        }
    }

}
