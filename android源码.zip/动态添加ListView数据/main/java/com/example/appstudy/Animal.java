package com.example.appstudy;

public class Animal {
    private String aName;
    private int aIcon;

    public Animal(){

    }

    public Animal(String name, int icon){
        this.aName = name;
        this.aIcon = icon;
    }

    public String getaName(){
        return aName;
    }


    public int getaIcon(){
        return aIcon;
    }

    public void setaName(String name){
        this.aName = name;
    }

    public void setaIcon(int icon){
        this.aIcon = icon;
    }
}
