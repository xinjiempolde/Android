package com.example.appstudy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.appstudy.Animal;
import java.util.LinkedList;

public class AnimalAdapter extends BaseAdapter {

    private LinkedList<Animal> mDate;
    private Context context;
    public AnimalAdapter(LinkedList<Animal> mDate,Context context){
        this.mDate = mDate;
        this.context = context;
    }
    @Override
    public int getCount() {
        return mDate.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.img = (ImageView) convertView.findViewById(R.id.imgtou);
            viewHolder.txt_name = (TextView) convertView.findViewById(R.id.name);
            convertView.setTag(viewHolder);
        }else {
           viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.img.setBackgroundResource(mDate.get(position).getaIcon());
        viewHolder.txt_name.setText(mDate.get(position).getaName());
        return convertView;
    }

    public void add(Animal date){
        if (mDate == null){
            mDate = new LinkedList<>();
        }
        mDate.add(date);
        notifyDataSetChanged();
    }

    static class ViewHolder{
        ImageView img;
        TextView txt_name;
    }
}
