package com.example.appstudy;

public class Animal {
    private String aName;
    private String aSpeak;
    private int aIcon;

    public Animal(){

    }

    public Animal(String name, String speak, int icon){
        this.aName = name;
        this.aSpeak = speak;
        this.aIcon = icon;
    }

    public String getaName(){
        return aName;
    }

    public String getaSpeak(){
        return aSpeak;
    }

    public int getaIcon(){
        return aIcon;
    }

    public void setaName(String name){
        this.aName = name;
    }

    public void setaSpeak(String speak){
        this.aSpeak = speak;
    }

    public void setaIcon(int icon){
        this.aIcon = icon;
    }
}
