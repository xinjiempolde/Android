package com.example.appstudy;

public class Course {
    private String CourseName;
    private String Position;
    private String Week;
    private String Col;
    private String Row;

    public String getCourseName() {
        return CourseName;
    }

    public String getWeek() {
        return Week;
    }

    public void setCol(String col) {
        Col = col;
    }

    public void setCourseName(String courseName) {
        CourseName = courseName;
    }

    public void setPosition(String position) {
        Position = position;
    }

    public void setRow(String row) {
        Row = row;
    }

    public void setWeek(String week) {
        Week = week;
    }
}
