package com.example.appstudy;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{
    private Button btn;
    private ArrayList<Course> mCourses;
    private TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button)findViewById(R.id.btn);
        int tvId = getResources().getIdentifier("tv","id","com.example.appstudy");
        tv = (TextView)findViewById(tvId);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strjson = getJson("jsonfile.json",MainActivity.this);
                parseEasyJson(strjson);
                for (int i = 0; i < mCourses.size(); i++){
                    Log.e("json",mCourses.get(i).getCourseName());
                }
                tv.setText(mCourses.get(0).getCourseName());
            }
        });
    }

    private void parseEasyJson(String json){
        mCourses = new ArrayList<Course>();
        try{
            JSONArray jsonArray = new JSONArray(json);
            for(int i = 0;i < jsonArray.length();i++){
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                Course course = new Course();
                course.setCourseName(jsonObject.getString("course"));
                course.setPosition(jsonObject.getString("room"));
                course.setWeek(jsonObject.getString("week"));
                course.setCol(jsonObject.getString("col"));
                course.setRow(jsonObject.getString("row"));
                mCourses.add(course);
            }
        }catch (Exception e){e.printStackTrace();}
    }

    public static String getJson(String fileName, Context context) {
        //将json数据变成字符串
        StringBuilder stringBuilder = new StringBuilder();
        try {
            //获取assets资源管理器
            AssetManager assetManager = context.getAssets();
            //通过管理器打开文件并读取
            BufferedReader bf = new BufferedReader(new InputStreamReader(
                    assetManager.open(fileName)));
            String line;
            while ((line = bf.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }

}
