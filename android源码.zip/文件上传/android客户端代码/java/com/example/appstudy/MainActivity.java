package com.example.appstudy;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends Activity {
	public static final MediaType MEDIA_TYPE_PNG = MediaType.parse("image/png");

	//读写权限
	private static String[] PERMISSIONS_STORAGE = {
			android.Manifest.permission.READ_EXTERNAL_STORAGE,
			android.Manifest.permission.WRITE_EXTERNAL_STORAGE};    //请求状态码
	private static int REQUEST_PERMISSION_CODE = 2;
	private EditText editText;
	private Context mContext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS_STORAGE, REQUEST_PERMISSION_CODE);
		}
		mContext = this;
		// 申请并获得权限
		if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
			ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE} ,1);
		}
		// 获取控件
		editText = (EditText) findViewById(R.id.et_filepath);
		Button btUpload = (Button) findViewById(R.id.bt_upload);
		btUpload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				fileupload(new Callback() {
					@Override
					public void onFailure(Call call, IOException e) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								Toast.makeText(mContext, "上传失败！", Toast.LENGTH_SHORT).show();
							}
						});
					}

					@Override
					public void onResponse(Call call, Response response) throws IOException {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								Toast.makeText(mContext, "上传成功！", Toast.LENGTH_SHORT).show();
							}
						});
					}
				});
			}
		});
	}

	public void fileupload(Callback callback) {
		// 获得输入框中的路径
		String path = editText.getText().toString().trim();
		File file = new File(path);
		OkHttpClient client = new OkHttpClient();
		// 上传文件使用MultipartBody.Builder
		RequestBody requestBody = new MultipartBody.Builder()
				.setType(MultipartBody.FORM)
				.addFormDataPart("username", "sunhaiyu") // 提交普通字段
				.addFormDataPart("image", file.getName(), RequestBody.create(MEDIA_TYPE_PNG, file)) // 提交图片，第一个参数是键（name="第一个参数"），第二个参数是文件名，第三个是一个RequestBody
				.build();
		// POST请求
		Request request = new Request.Builder()
				.url("http://39.96.26.6:8080/myFirstServlet/one")
				.post(requestBody)
				.build();
		client.newCall(request).enqueue(callback);
	}
}