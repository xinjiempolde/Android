package com.example.appstudy;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button btnup, btndown;
    private ScrollView scrollView;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
    }

    public void bindViews(){
        btnup = (Button)findViewById(R.id.top);
        btndown = (Button)findViewById(R.id.buttom);
        scrollView = (ScrollView)findViewById(R.id.scroll);
        btnup.setOnClickListener(this);
        btndown.setOnClickListener(this);
        textView = (TextView)findViewById(R.id.txt);
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < 100; i++){
            str.append("你真棒" + "*" + i + "\n");
        }
        textView.setText(str.toString());
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.top:
                scrollView.fullScroll(ScrollView.FOCUS_UP);
                break;
            case R.id.buttom:
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                break;
        }
    }

}
