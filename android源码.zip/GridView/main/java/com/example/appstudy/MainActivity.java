package com.example.appstudy;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity{
    private Context mContext;
    private GridView grid_photo;
    private BaseAdapter mAdapter = null;
    private ArrayList<Icon> mDate = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = MainActivity.this;
        grid_photo = (GridView)findViewById(R.id.grid_photo);

        mDate = new ArrayList<Icon>();

        mDate.add(new Icon(R.mipmap.head_icon1,"图标1"));
        mDate.add(new Icon(R.mipmap.head_icon1,"图标1"));
        mDate.add(new Icon(R.mipmap.head_icon1,"图标1"));
        mDate.add(new Icon(R.mipmap.head_icon1,"图标1"));
        mDate.add(new Icon(R.mipmap.head_icon1,"图标1"));
        mDate.add(new Icon(R.mipmap.head_icon1,"图标1"));

        mAdapter = new MyAdapter<Icon>(mDate,R.layout.item_grid_icon) {
            @Override
            public void bindView(ViewHolder holder, Icon obj){
                holder.setImageResource(R.id.img_icon, obj.getiId());
                holder.setText(R.id.txt_icon,obj.getiName());
            }
        };

        grid_photo.setAdapter(mAdapter);
    }
}