package com.example.appstudy;

import android.content.ClipData;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class MyBaseExpandableListAdapter extends BaseExpandableListAdapter {
    private ArrayList<Group> gDate;
    private ArrayList<ArrayList<Item>> iDate;
    private Context context;

    public MyBaseExpandableListAdapter(ArrayList<Group> gDate, ArrayList<ArrayList<Item>> iDate, Context context){
        this.gDate = gDate;
        this.iDate = iDate;
        this.context = context;
    }
    @Override
    public int getGroupCount() {
        return gDate.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return iDate.get(groupPosition).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return gDate.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return iDate.get(groupPosition).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        ViewHolderGroup groupHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_exlist_group, parent, false);
            groupHolder = new ViewHolderGroup();
            groupHolder.tv_group_name = (TextView) convertView.findViewById(R.id.tv_group_name);
            convertView.setTag(groupHolder);
        }else{
            groupHolder = (ViewHolderGroup) convertView.getTag();
        }
        groupHolder.tv_group_name.setText(gDate.get(groupPosition).getName());
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ViewHolderItem itemholder;
        if (convertView == null){
            convertView = LayoutInflater.from(context).inflate(R.layout.item_exlist_item,parent,false);
            itemholder = new ViewHolderItem();
            itemholder.img_icon = (ImageView)convertView.findViewById(R.id.img_icon);
            itemholder.tv_name = (TextView)convertView.findViewById(R.id.tv_name);
            convertView.setTag(itemholder);
        }else {
            itemholder = (ViewHolderItem)convertView.getTag();
        }
        itemholder.img_icon.setImageResource(iDate.get(groupPosition).get(childPosition).getIcon());
        itemholder.tv_name.setText(iDate.get(groupPosition).get(childPosition).getName());
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    private static class ViewHolderGroup{
        private TextView tv_group_name;
    }

    private static class ViewHolderItem{
        private ImageView img_icon;
        private TextView tv_name;
    }
}
