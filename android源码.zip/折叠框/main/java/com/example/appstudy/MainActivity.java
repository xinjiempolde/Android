package com.example.appstudy;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ExpandableListView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity{
    private ArrayList<Group> gDate = null;
    private ArrayList<Item> lDate = null;
    private ArrayList<ArrayList<Item>> iDate = null;
    private ExpandableListView exlist;
    private MyBaseExpandableListAdapter adapter = null;
    private Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = MainActivity.this;
        exlist = (ExpandableListView)findViewById(R.id.exlist_test);
        gDate = new ArrayList<Group>();
        gDate.add(new Group("AD"));
        gDate.add(new Group("AP"));

        //AD
        lDate = new ArrayList<Item>();
        lDate.add(new Item(R.mipmap.head_icon1,"AD1"));
        lDate.add(new Item(R.mipmap.head_icon2,"AD2"));
        lDate.add(new Item(R.mipmap.head_icon3,"AD3"));
        iDate = new ArrayList<ArrayList<Item>>();
        iDate.add(lDate);
        //AP
        lDate = new ArrayList<Item>();
        lDate.add(new Item(R.mipmap.head_icon1,"AP1"));
        lDate.add(new Item(R.mipmap.head_icon2,"AP2"));
        lDate.add(new Item(R.mipmap.head_icon3,"AP3"));
        iDate.add(lDate);
        adapter = new MyBaseExpandableListAdapter(gDate,iDate,mContext);
        exlist.setAdapter(adapter);
        ExlistListener listener = new ExlistListener();
        exlist.setOnChildClickListener(listener);
    }
    private class ExlistListener implements ExpandableListView.OnChildClickListener{
        @Override
        public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
            Toast.makeText(mContext,"你点击了" + iDate.get(groupPosition).get(childPosition).getName(),Toast.LENGTH_SHORT).show();
            return true;
        }
    }
}