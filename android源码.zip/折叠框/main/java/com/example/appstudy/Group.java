package com.example.appstudy;

public class Group {
    private String Name;

    public Group(String Name){
        this.Name = Name;
    }

    public String getName() {
        return Name;
    }
}
